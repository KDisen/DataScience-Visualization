#!/usr/bin/env python
# coding: utf-8

# In[1]:


#Keven Disen 111433335
#BME 361
#4/15/20
#HW Coronavirus part 2 (Global Confirmed Over Time)

#Conclusion:
#From this, we can conclude that the seconda and third countries to get exposed and have confirmed cases
# of CoVID-19 are Eastern countries, South Korea and Iran.
#We can also tell that Russia was one of the latest countries to announce confirmations of the coronavirus.


# In[2]:


import plotly as py
import plotly.express as px
import plotly.graph_objs as go
from plotly.subplots import make_subplots
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import folium
import branca.colormap as cm
get_ipython().run_line_magic('matplotlib', 'inline')

get_ipython().run_line_magic('matplotlib', 'inline')


# In[3]:


global_data = pd.read_csv('time_series_covid19_confirmed_global.csv')
global_data_2 = global_data.groupby(global_data['Country/Region']).agg(sum)

global_data_2.insert(loc=0, column='Countries', value=global_data_2.index.values)  # insert a new column to store state abbreviations
global_data_3=global_data_2.reset_index(drop=True)  # to remove the current index. It was full state name. 
global_data_3 = global_data_3.drop(columns=['Lat','Long'])  # Remove a few columns that are not useful for analylsis
global_data_3.tail(50)


# In[4]:


myscale = (global_data_2['4/4/20'].quantile([0, 0.35, 0.7, 0.90, 1])).tolist()   
# tolist() is not necessary here but to keep consistant of data format
myscale


# In[5]:


dates_list = list(global_data_2.columns.values)[1::]   # Only choose the column names with dates
global_data_reorg = global_data_2.melt(id_vars=['Countries'], value_vars=dates_list) # This is a magic function

# change the names of columns
global_data_reorg = global_data_reorg.rename(columns={'variable':'dates', 'Countries':'Countries','value':'cases'})
global_data_reorg=global_data_reorg[['dates','Countries','cases']]  # switch columns

# take log10 to each value in the case column
import numpy as np
global_data_reorg['cases'] = global_data_reorg['cases'].map(lambda x:np.log10(x+1000))
global_data_reorg = global_data_reorg.replace(to_replace ="Lat", 
                 value ="0")


# In[6]:


# Nowe we manually change the colormap
fig = px.choropleth(global_data_reorg, 
                    locations="Countries", 
                    locationmode = "country names",
                    color=global_data_reorg["cases"],  # Take log scale. Add 1 to all values, otherwise log10(0) is wrong
                    color_continuous_scale=px.colors.sequential.Jet,  # try other colors? like RdBu, thermal,..
                    animation_frame="dates",
                    scope="world"
                   )

# customize the figure title and overall information
fig.update_layout(
    title_text = 'Cases of Coronavirus in the US over time',
    title_x = 0.5,
    )

# Customize the color bar and color scale. 
#Note the color bar is automatically updated for best visualization.
fig.update_layout(
    coloraxis_colorbar=dict(
        title="Cases",
        tickvals=[0,1,2,3,4,5],     
# Well, you can also do quantile scale by manually defining the thresholds
        ticktext=['0','10','100','1000','10000','100000']  
        # Show the labels besides the color bar
    ))

fig.show()


# In[ ]:




