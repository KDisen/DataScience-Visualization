#!/usr/bin/env python
# coding: utf-8

# In[1]:


#Keven Disen 111433335
#BME 361
#Coronavirus US Deaths Homework part 1
#4/15/20

#Conclusion:
#From this, we can conclude that the first few deaths that 
# occurred in the United States began in Washington State on 2/29
#We can also say that New York death toll rapidly increades in 10 days. 
#From 3/13 to 3/23 it had more deaths than Washington state.


# In[2]:


import plotly.express as px
from plotly.subplots import make_subplots
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import folium
import branca.colormap as cm
get_ipython().run_line_magic('matplotlib', 'inline')

get_ipython().run_line_magic('matplotlib', 'inline')


# In[3]:


US_data = pd.read_csv('time_series_covid19_deaths_US.csv')
US_data_2 = US_data.groupby(US_data['Province_State']).agg(sum)
US_data_2.head(20)


# In[4]:


US_data_2.insert(loc=0, column='state_abb', value=US_data_2.index.values)  # insert a new column to store state abbreviations
US_data_3=US_data_2.reset_index(drop=True)  # to remove the current index. It was full state name. 
US_data_3 = US_data_3.drop(columns=['UID', 'code3','FIPS', 'Lat','Long_'])  # Remove a few columns that are not useful for analylsis
US_data_3


# In[5]:


us_state_abbrev = {
    'Alabama': 'AL',
    'Alaska': 'AK',
    'Arizona': 'AZ',
    'Arkansas': 'AR',
    'California': 'CA',
    'Colorado': 'CO',
    'Connecticut': 'CT',
    'Delaware': 'DE',
    'District of Columbia': 'DC',
    'Florida': 'FL',
    'Georgia': 'GA',
    'Hawaii': 'HI',
    'Idaho': 'ID',
    'Illinois': 'IL',
    'Indiana': 'IN',
    'Iowa': 'IA',
    'Kansas': 'KS',
    'Kentucky': 'KY',
    'Louisiana': 'LA',
    'Maine': 'ME',
    'Maryland': 'MD',
    'Massachusetts': 'MA',
    'Michigan': 'MI',
    'Minnesota': 'MN',
    'Mississippi': 'MS',
    'Missouri': 'MO',
    'Montana': 'MT',
    'Nebraska': 'NE',
    'Nevada': 'NV',
    'New Hampshire': 'NH',
    'New Jersey': 'NJ',
    'New Mexico': 'NM',
    'New York': 'NY',
    'North Carolina': 'NC',
    'North Dakota': 'ND',
    'Northern Mariana Islands':'MP',
    'Ohio': 'OH',
    'Oklahoma': 'OK',
    'Oregon': 'OR',
    'Palau': 'PW',
    'Pennsylvania': 'PA',
    'Puerto Rico': 'PR',
    'Rhode Island': 'RI',
    'South Carolina': 'SC',
    'South Dakota': 'SD',
    'Tennessee': 'TN',
    'Texas': 'TX',
    'Utah': 'UT',
    'Vermont': 'VT',
    'Virgin Islands': 'VI',
    'Virginia': 'VA',
    'Washington': 'WA',
    'West Virginia': 'WV',
    'Wisconsin': 'WI',
    'Wyoming': 'WY',
}


# In[6]:



# We use abbreviation to replace the state names
US_data_3['state_abb'] = US_data_3['state_abb'].map(lambda x: us_state_abbrev[x] if x in list(us_state_abbrev.keys()) else x)
US_data_4 = US_data_3[US_data_3['state_abb'].map(lambda x: len(x)<3)]
US_data_4
US_data_final =US_data_4.groupby(by='state_abb', as_index =False).agg('sum')
US_data_final




# In[7]:


myscale = (US_data_final['4/4/20'].quantile([0, 0.35, 0.7, 0.90, 1])).tolist()   
# tolist() is not necessary here but to keep consistant of data format
myscale


# In[8]:


state_geo = 'US_geo.json'  # this file should be downloaded from blackboard. 



Cov_US = folium.Map(location=[48, -102], zoom_start=4)

folium.Choropleth(
    geo_data=state_geo,
    name='choropleth',
    data=US_data_final,
    columns=['state_abb', '4/4/20'],
    key_on='feature.id',
    threshold_scale=myscale,
    fill_color='YlOrRd',   # more color from cm.linear
    fill_opacity=0.5,
    line_opacity=0.1,
    legend_name='Cases'
).add_to(Cov_US)

folium.LayerControl().add_to(Cov_US)

Cov_US


# In[9]:


dates_list = list(US_data_final.columns.values)[1::]   # Only choose the column names with dates
US_data_reorg = US_data_final.melt(id_vars=['state_abb'], value_vars=dates_list) # This is a magic function
US_data_reorg 


# In[10]:


# change the names of columns
US_data_reorg = US_data_reorg.rename(columns={'variable':'dates', 'state_abb':'State','value':'deaths'})
US_data_reorg=US_data_reorg[['dates','State','deaths']]  # switch columns

# take log10 to each value in the case column
import numpy as np
US_data_reorg['deaths'] = US_data_reorg['deaths'].map(lambda x:np.log10(x+1))

US_data_reorg


# In[11]:


# Nowe we manually change the colormap
fig = px.choropleth(US_data_reorg, 
                    locations="State", 
                    locationmode = "USA-states",
                    color=US_data_reorg["deaths"],  # Take log scale. Add 1 to all values, otherwise log10(0) is wrong
                    color_continuous_scale=px.colors.sequential.Jet,  # try other colors? like RdBu, thermal,..
                    animation_frame="dates",
                    scope="usa"
                   )

# customize the figure title and overall information
fig.update_layout(
    title_text = 'Deaths of Coronavirus in the US over time',
    title_x = 0.5,
    )

# Customize the color bar and color scale. 
#Note the color bar is automatically updated for best visualization.
fig.update_layout(
    coloraxis_colorbar=dict(
        title="Deaths",
        tickvals=[0,1,2,3,4,5],     
# Well, you can also do quantile scale by manually defining the thresholds
        ticktext=['0','10','100','1000','10000','100000']  
        # Show the labels besides the color bar
    ))

fig.show()



# In[ ]:




