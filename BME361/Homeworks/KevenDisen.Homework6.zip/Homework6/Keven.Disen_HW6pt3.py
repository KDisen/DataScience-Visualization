#!/usr/bin/env python
# coding: utf-8

# In[1]:


#Keven Disen 111433335
#BME 361
#4/15/20
#HW Coronavirus part 3 (Global Deaths)

#Conlusion:
#From this map, we can see that the 2 countries with the highest deaths on 4/4/20 
# are Italy with 15362 deaths and Spain with 11947 deaths


# In[2]:


import plotly as py
import plotly.express as px
import plotly.graph_objs as go
from plotly.subplots import make_subplots
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import folium
import branca.colormap as cm
get_ipython().run_line_magic('matplotlib', 'inline')

get_ipython().run_line_magic('matplotlib', 'inline')


# In[3]:


globaldata = pd.read_csv('time_series_covid19_deaths_global.csv')


# In[4]:


globaldata2 = globaldata.groupby(globaldata['Country/Region']).agg(sum)

globaldata2.insert(loc=0, column='Countries', value=globaldata2.index.values)  # insert a new column to store state abbreviations
globaldata3=globaldata2.reset_index(drop=True)  # to remove the current index. It was full state name. 
globaldata3 = globaldata3.drop(columns=['Lat','Long'])  # Remove a few columns that are not useful for analylsis
globaldata3.tail(50)


# In[5]:


circle_plot = folium.Map([48, -102], tiles='Stamen Terrain', zoom_start=1)

radius_min = 1.5
radius_max = 35

# We use this feature layer to include all the circle layers created in the following for loop. 
group_circles = folium.FeatureGroup(name='Deaths')

# Use for loop to add circles one by one. One circle is one layer of figure.
for i in range(len(globaldata)):
    lat = globaldata.loc[i, 'Lat']
    lon = globaldata.loc[i, 'Long']
    location = str(globaldata.loc[i, 'Country/Region']) if str(globaldata.loc[i, 'Province/State'])== 'NaN' else str(globaldata.loc[i, 'Country/Region'])+', '+ str(globaldata.loc[i, 'Province/State']) 
    cases = str(globaldata.loc[i, '4/4/20'])    # Let's choose the last column to visualize
    
    radius_circle = np.log10(globaldata.loc[i, '4/4/20']+1)*5   # define the size of circles
    radius_circle = radius_min if (radius_circle < radius_min) else radius_circle 
    radius_circle = radius_max if (radius_circle > radius_max) else radius_circle 
    
    folium.CircleMarker(location = [lat,lon], 
                        radius = radius_circle, 
                        popup = location +'; \n'+ cases + ' deaths', # this pop up when clicking the circle
                        color = 'red', 
                        fill_opacity = 0.5,
                        weight = 1, 
                        fill = True, 
                        fillColor = 'red').add_to(group_circles)

# Now add all the circles in the map
group_circles.add_to(circle_plot)   

# You can click on and off the feature layer
folium.LayerControl().add_to(circle_plot)

circle_plot



# In[ ]:




