#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#Keven Disen
#111433335
#BME 361
#HW7
#4/27/20

#Conclusion: The numbers could've been wrongly recognized because 
#when shown the heatmap with the array test, the numbers sometimes don't look like its real number


# In[8]:


import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from skimage import data, color
from skimage.transform import rescale, resize, downscale_local_mean
import numpy as np
import pandas as pd
import seaborn as sns




# In[9]:


# write a digit, and take a picture using cellphone

imageList = 'IMG_1317-1.JPEG', 'IMG_1317.JPEG', 'IMG_1317-2.JPEG', 'IMG_1317-3.JPEG', 'IMG_1317-4.JPEG', 'IMG_1317-5.JPEG', 'IMG_1317-6.JPEG', 'IMG_1317-7.JPEG', 'IMG_1317-1.JPEG', 'IMG_1317-9.JPEG', 'IMG_1317-10.JPEG', 'IMG_1317-11.JPEG', 'IMG_1317-12.JPEG', 'IMG_1317-13.JPEG', 'IMG_1317-14.JPEG', 'IMG_1317-15.JPEG', 'IMG_1317-14.JPEG', 'IMG_1317-17.JPEG', 'IMG_1317-18.JPEG', 'IMG_1317-13.JPEG'



img = np.array(imageList)
numImage = []

for i in range(len(img)):
    im= mpimg.imread(img[i])
    image = color.rgb2grey(im) #Converts image to grey
    image_resized = resize(image, (8, 8), anti_aliasing=False) # False maximize the contrast
    image_inverse = (1-image_resized) #gets inverse color of image
    
    plt.figure()
    image_final = (image_inverse-image_inverse.min()) * 16 / (image_inverse.max()-image_inverse.min())
    #plt.imshow(image_final, cmap = 'Greys')
    numImage.append(image_final.flatten())
    
    array_test = pd.DataFrame (image_final, range(8), range(8))
    figure = plt.figure(figsize=(3,2))  
    axes = sns.heatmap (array_test, annot=True, 
                   cmap=plt.cm.gray_r)

    axes.set_ylim(sorted(axes.get_xlim(), reverse=True)) # this script is to correct a bug in aligning digits
    
numImage = np.array(numImage) #array with images    
numReal = 8, 2, 0, 0, 3, 5, 1, 5, 8, 7, 5, 1, 9, 6, 4, 2, 4, 0, 7, 6 #array with target numbers

#I have had some trouble with printing the picture and the target number above it


# ### SVM Machine Learning Model

# In[105]:


from sklearn.model_selection import train_test_split
from sklearn import svm
from sklearn.datasets import load_digits
digits = load_digits()
X_train, X_test, y_train, y_test = train_test_split(numImage, numReal,test_size = 0.2, random_state=20)



clf = svm.SVC(kernel ='poly')
clf.fit(X_train, y_train)
predicted = clf.predict(X=numImage)  # this is predicted data
expected = numReal #expected data


from sklearn.metrics import accuracy_score

acc = accuracy_score(expected, predicted)
print("Accuracy score using SVC", acc*100)

from sklearn.metrics import confusion_matrix
confusion = confusion_matrix(expected, predicted)
confusion
import pandas as pd
import seaborn as sns

confusion_df = pd.DataFrame (confusion, range(10), range(10))
figure = plt.figure(figsize=(6,5))  
axes = sns.heatmap (confusion_df, annot=True, 
                   cmap=plt.cm.nipy_spectral_r)

axes.set_ylim(sorted(axes.get_xlim(), reverse=True))


# ### Random Forest

# In[104]:


from sklearn.ensemble import RandomForestClassifier

# random forest is a supervised learning algorithm that 
#randomly creates and merges multiple decision trees into one “forest.”

rF = RandomForestClassifier(n_estimators=100,
                            criterion='gini',
                            max_depth=None,
                            min_samples_split=2,
                            min_samples_leaf=1,
                            max_features='auto',
                            max_leaf_nodes=None,
                            min_weight_fraction_leaf=0.0,
                            random_state=None)  


rF.fit(X_train, y_train)
y_pred = rF.predict(numImage)
accR = accuracy_score(expected, y_pred)
#Accuracy of algorithm
print("Accuracy score using Random Forest", accR*100)



# In[ ]:




